export default function Dashboard(props){
    const style = {
        root: {
            "marginLeft": 100
        }
    }
    return (
        <div style={style.root}>
            This is My Dashboard!!!
        </div>
    )
}