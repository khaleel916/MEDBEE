import RiskForm from "./RiskForm";
import MedicationSafetyForm from "./MedicationSafetyForm";
import IndicatorForSurgicalForm from "./IndicatorForSurgicalForm";
import VarianceSafteyForm from "./VarianceSafteyForm";

export const samples = {
 RiskForm,
 MedicationSafetyForm,
 IndicatorForSurgicalForm,
 VarianceSafteyForm
};
